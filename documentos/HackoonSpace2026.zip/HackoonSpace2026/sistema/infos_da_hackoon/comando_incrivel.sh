#!/bin/bash

echo "🔧 Procurando por informações secretas............"

# =========================
# 1. CRIAR FAQ
# =========================
cat <<EOF > perguntas_frequentes.txt
[FAQ INTERNO - HACKOONSPACE]

Pergunta: O café da Hackoon acaba rápido?
Resposta: Sim. Misteriosamente rápido.

Pergunta: Existe um guaxinim oficial da Hackoon?
Resposta: Oficialmente não. Extraoficialmente, talvez ele esteja observando.

Pergunta: Quantos cabos são demais em uma bancada?
Resposta: O limite técnico não existe. O limite emocional, sim.

Pergunta: O modo escuro melhora o desempenho?
Resposta: Não comprovado, mas melhora a autoestima do terminal.

Pergunta: A senha do Wi-Fi é "hackoon123"?
Resposta: Não. E se fosse, esse arquivo não contaria.

Pergunta: Ler tudo manualmente é uma boa ideia?
Resposta: Só se você tiver tempo, paciência e nenhum comando no terminal.

Pergunta: Onde estão os stickers da Hackoon?
Resposta: Provavelmente com alguém que disse “depois eu devolvo”.

Pergunta: Existe vida inteligente nos logs?
Resposta: Debate em aberto.

Pergunta: Onde está a senha e login da Hackoon?
Resposta: Em uma pasta de credenciais escondida. Talvez você precise voltar ao começo para chegar ao final.

Pergunta: O arquivo antigo.log tem alguma coisa útil?
Resposta: Útil para testar sua paciência.

Pergunta: O usuário admin_fake é confiável?
Resposta: O nome já responde.

Pergunta: Posso confiar em arquivos muito óbvios?
Resposta: Esse sistema recompensa desconfiança.

Pergunta: O comando ls mostra tudo?
Resposta: Depende do quanto você realmente quer ver.

Pergunta: Existe uma flag neste FAQ?
Resposta: Não. Mas existe uma dica que vale mais que uma flag.

Pergunta: A Hackoon esconde segredos em pastas invisíveis?
Resposta: Seria irresponsável confirmar isso.
EOF

# =========================
# 2. CRIAR backup_perguntas_frequentes.txt
# =========================
cat <<EOF > backup_perguntas_frequentes.txt
[ARQUIVO DE BACKUP]
Pergunta: O que aconteceu com todas as perguntas respondidas pela equipe da Hackoon?
Resposta: Por algum motivo durante a recuperação dos arquivos, o arquivo foi corrompido... 
Resposta: Talvez, um usuário admin possa ter a resposta de como desbloquear o arquivo... 
EOF

# =========================
# 3. BLOQUEAR FAQ
# =========================
chmod 000 perguntas_frequentes.txt


# =========================
# 4. CRIAR PASTA OCULTA
# =========================
cd ..
cd ..
mkdir -p .credenciais

# =========================
# ENTRAR NA PASTA .credenciais
# =========================
cd .credenciais || exit

# =========================
# 5. CRIAR acesso.b64
# =========================
cat <<EOF > acesso.b64
bG9naW46IGhhY2tvb25fc3BhY2UKc2VuaGE6c2VuaGFtdWl0b2ZvcnRlMTIzCgo=
EOF

# =========================
# 6. CRIAR dica.sh
# =========================
cat <<'EOF' > dica.sh
echo -e "\033[1;33mBom... você conseguiu executar.\033[0m

\033[1;32mIsso significa que nem tudo é apenas texto.\033[0m

\033[1;35mAgora preste atenção...\033[0m

\033[1;34mAlgumas informações não estão escondidas...\033[0m
\033[1;34melas apenas foram transformadas.\033[0m

\033[1;36mExiste um padrão comum para isso.\033[0m

\033[1;31mBase...\033[0m
\033[1;31m64.\033[0m

\033[1;33mSe você encontrou algo estranho...\033[0m
\033[1;33mtalvez ele só precise ser decodificado.\033[0m

\033[1;36mFluxo sugerido:\033[0m

\033[1;36mcat\033[0m acesso.b64 \033[1;33m|\033[0m \033[1;36mbase64 -d\033[0m
"
EOF

# =========================
# 7. PERMISSÃO DE EXECUÇÃO
# =========================
chmod +x dica.sh

# voltar pro diretório anterior (opcional)
cd ..

echo "🎯 Setup completo! Quem sabe algumas perguntas frequentes tenham a resposta?"
