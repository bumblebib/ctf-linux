echo -e "\033[1;33mBom... você conseguiu executar.\033[0m

\033[1;32mIsso significa que nem tudo é apenas texto.\033[0m

\033[1;35mAgora preste atenção...\033[0m

\033[1;34mAlgumas informações não estão escondidas...\033[0m
\033[1;34melas apenas foram transformadas.\033[0m

\033[1;36mExiste um padrão comum para isso.\033[0m

\033[1;31mBase...\033[0m
\033[1;31m64.\033[0m

\033[1;33mSe você encontrou algo estranho...\033[0m
\033[1;33mtalvez ele só precise ser decodificado.\033[0m

\033[1;36mFluxo sugerido:\033[0m

\033[1;36mcat\033[0m acesso.b64 \033[1;33m|\033[0m \033[1;36mbase64 -d\033[0m
"
